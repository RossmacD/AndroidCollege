# Exercise TTS Coach Application
### Mobile Computing Module | IADT Creative Computing | Year 3
Written by Ross MacDonald - N00171147

This is an android application with the goal of being a Text to Speech exercise coach.
The Core functionality is that you can add exercises and then create a workout from these exercises and have text to speech count in a rythm to motivate you.
